(() => {
  const params = JSON.parse(document.currentScript.dataset.params);
  eval(params.scriptToEval);
})();