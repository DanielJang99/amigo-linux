(()=> {  
  // global parameters 
  var full_key   = [];           
  var full_data  = [];       
  var lastDump   = Date.now();   // keep track when last webrtc data was dumped 
  var wasTabClosed = false 
  var key_to_send = [] 
  var data_to_send = [] 
  var wasDumped = false; 
  var confStarted = false; 
  var gridClicked = false; 
  var viewClicked = false; 
  var DUMP_INT   = 90 * 1000;     // timeout to ask user to hang up and collect data for webex
  
  const params = JSON.parse(document.currentScript.dataset.params);
  var editorExtensionId = params.addonId;
  // NOTE: the id changes when used local (e.g., from folder) versus published (e.g., crx from Google)
  // var editorExtensionId = "hgplgkibjnndogdgejjhkjjnhalfiebb";   // identifier of crx from Google  
  //var editorExtensionId = "dmhcpaafdfgdkjpjeiidlhnpcaholnba"; // brave local identifier @macOS
  //var editorExtensionId = "dmhcpaafdfgdkjpjeiidlhnpcaholnba"; // chrome local idenifier @macOS
  //var editorExtensionId = "ialdcflhhckncoimpnngapimjmapghne"; // local identifier @starlink machine  
  //var editorExtensionId = "ojljhcakhppmlnkhfagcchdmlpnpkinc"; // local identifier @starlink machine

  // // reduce duration if we are debugging
  // if(editorExtensionId != "hgplgkibjnndogdgejjhkjjnhalfiebb"){
  //   console.log("Debugging. Reducing duration to 30 seconds...")
  //   DUMP_INT   = 30 * 1000; 
  // }


  // update DUMP_INT duration (not sure why this does not work...) // FIXME
  /*chrome.runtime.sendMessage(editorExtensionId, {name:'get_timer'}, (response) => {
    DUMP_INT = response['MAX_VIDEOCONF_DUR']
    console.log("Updating timers. DUMP_INT:", DUMP_INT); 
  })
  */

  // discover remotely extension id (not working, some CORS crap)
  //var active_url = window.location.toString();  
  // var app = "None"
  // if(active_url.includes("zoom")){ 
  //   app = "zoom"
  // } else if (active_url.includes("webex")){ 
  //   app = "webex"
  // } else if (active_url.includes("meet")){ 
  //   app = "meet"
  // }  
  // console.log("App:", app)
  // if(app != "webex"){ 
  //   const curr_url = "https://mobile.batterylab.dev:8084/addonid"
  //   console.log("[inject] testing post ") 
  //   var data = {"uid":"inject"};
  //   fetch(curr_url, {     
  //       method: "POST",             
  //       body: JSON.stringify(data),             
  //       headers: {
  //           "Content-type": "application/json;"
  //       }
  //   }) 
  //   .then(function (response) {
  //     console.log("[inject] data successfully posted! Response:", response.json());
  //   })
  //   .catch(function (err) {
  //       console.log(" [inject] something went wrong with POST"); 
  //   });      
  // }
  

  // avoid running twice for webex -- does not solve audio joining issue though  
  var active_url = window.location.toString();    
  var timePassed = Date.now() - lastDump;   
  if(active_url.includes("extension-meetingapi")){ 
    console.log("[inject.js] TimePassed: ", timePassed, "Detected extension-meetingapi for webex. Leaving...")
    chrome.runtime.sendMessage(editorExtensionId, {name:'sendpost'}, (addon_response) => {
         console.log("[sendpost-inject.js] Response received", addon_response);
    })
    return false
  } else if(active_url === undefined){ 
    console.log("[inject.js] TimePassed: ", timePassed, "Detected undefined active URL");
    return false  
  } else if (active_url.includes("leave") && active_url.includes("zoom")){
    alert("👍 You can now close the tab, and return to the addon 👍");
    return false 
  } 
  console.log("[inject.js] TimePassed: ", timePassed, "Extension ID:", editorExtensionId, "wasTabClosed", wasTabClosed, "URL:", active_url); 
    
  // function to trace webrtc events 
  function trace(method, id, args) {
    var type = typeof args;   

    // Click "got it" from Meet (testing)
    //<span jsname="V67aGc" class="VfPpkd-vQzf8d">Got it</span>
    // var potential_elements = document.getElementsByClassName("VfPpkd-vQzf8d");
    // for (var i = 0; i < potential_elements.length; i++) { 
    //   if(potential_elements[i].includes('Got it')){
    //     console.log("Found node <<got it>> from meet -- clicking")
    //     potential_elements[i].click()      
    //   }
    // }

    // cancel dialog of audio issue with Webex
    var node = document.querySelector('[title="Cancel"]');
    if(node !== null){
      console.log("Found node <<Cancel>> - click. Resetting time to improve webex duration")
      lastDump   = Date.now();
      node.click()      
    }

    // WEBEX GRID -- make sure main video is "full screen" (or comparable to how it was in the past, no grid)
    var button = document.querySelector('[aria-label="Layout"]');
    if(button !== null && !gridClicked){
        console.log("Found WEBEX grid, opening it")
        button.click()
        gridClicked = true 
    } 


    button = document.querySelector('[aria-label="Stack"]');
    if(button !== null && !viewClicked){
        console.log("Found WEBEX view change, clicking it")
        button.click()
        viewClicked = true 
    } 

    // reset time for meet when "leave call" is found -- FIXME: not working anymore 
    var close = document.querySelector('[aria-label="Leave call"]');  
    if (close !== null && confStarted == false){
      confStarted = true
      console.log("Meet conference was correctly started. Resetting time for more accurate duration")
      lastDump   = Date.now();
    }
    
    // make sure args is valid 
    if (args === undefined || args === null) {
      return false;
    }

    // focus only on "getStats" // TBC: TEST IF WE MISS SOMETHING when focusing just on getStats
    if (method !== "getStats") {
      return false;
    }

    // old version, 05/2022    
    // // iterate on dictionary -- keys are not predictable     
    // if (type == "object"){
    //   const keys = Object.keys(args);
    //   key_to_send = [] 
    //   data_to_send = [] 
    //   // RTCMediaStreamTrack: redundant 
    //   // RTCOutboundRTPVideoStream: no guarantee on what user do (also no RTT in there )
    //   for (const [key, value] of Object.entries(args)) {        
    //     if (key.match(/^RTCIceCandidatePair/) != null) { // FIXME: no need to send all the time 
    //       key_to_send.push(key); 
    //       data_to_send.push(args[key]);
    //     } else if (key.match(/^RTCIceCandidate/) != null) { // FIXME: no need to send all the time
    //       key_to_send.push(key); 
    //       data_to_send.push(args[key]);
    //     } 
    //     else if (key.match(/^RTCInboundRTPVideoStream/) != null) { // By contrast to the Outbound RTP statistics, this stats contains data about the inbound video stream you are receiving from your peer(s). 
    //       key_to_send.push(key); 
    //       data_to_send.push(args[key]);
    //     } else if (key.match(/^RTCInboundRTPAudioStream/) != null) {  // This stats contains data about the inbound audio stream you are receiving from your peer(s).         
    //       key_to_send.push(key); 
    //       data_to_send.push(args[key]);                   
    //     } else if (key.match(/^RTCRemoteInboundRtpVideoStream/) != null) { //This stats report provides details about your outbound rtp stream from the perspective of the remote connection. That is to say that this stats report provides an analysis about your outbound-rtp stream from the perspective of the remote server that is handling your stream on the other side.
    //       key_to_send.push(key); 
    //       data_to_send.push(args[key]);
    //     }
    //     //////////////// testing
    //     //console.log(key, value)
    //     ///////////////////////
    //   }
    //   if (key_to_send.length > 0 && data_to_send.length > 0){
    //     sendResults(key_to_send, data_to_send, false); 
    //   }
    // }


    // new version, 11/21/2022 (webrtc change)
    //////////////// testing
    if (method == 'getStats'){
      key_to_send = [] 
      data_to_send = [] 
      const keys = Object.keys(args);
      for (const [key, value] of Object.entries(args)) {   
        // remote-candidate, 
        // webrtc-datachannel, data-channel (check for zoom)
        // TODO: save a list and check if anything useful         
        if (value['type'] == 'remote-inbound-rtp' || value['type'] == 'candidate-pair' || value['type'] == 'remote-candidate' || value['type'] == 'local-candidate' || value['type'] == 'inbound-rtp' || value['type'] == 'outbound-rtp'){          
          //console.log(key, value)
          key_to_send.push(value['type']); 
          data_to_send.push(value);
        } //else { // uncomment this to report all data (CHECK IF USEFUL AND NOT TOO MUCH)
          //key_to_send.push(value['type']); 
          //data_to_send.push(value);
        //} 
      }
      if (key_to_send.length > 0 && data_to_send.length > 0){
        console.log("send results")     
        sendResults(key_to_send, data_to_send, false); 
      }
    }   
    ///////////////////////
    
    // all good
    return true 
  }


  // helper function to upload results to our server (using background script) or save locally (needed by webex)
  function sendResults(key_to_send, data_to_send, wasTabClosed){
    
    if (editorExtensionId === null){
      return 
    }
    // find app under test     
    var userid = "webrtc"; // FIXME: would be nice to get it from the other script     
    var active_url = window.location.toString();  
    var app = "None"
    if(active_url.includes("zoom")){ 
      app = "zoom"
    } else if (active_url.includes("webex")){ 
      app = "webex"
    } else if (active_url.includes("meet")){ 
      app = "meet"
    }  
    var data = {
      "app"         : app,
      "timestamp"   : Date.now(),
      "webrtc-data" : data_to_send
    }
    
    // switch between upload results and save to file for webex (since not allowed to communicate with background)
    var timePassed = Date.now() - lastDump; 
    console.log("[inject.js][sendResults] TimePassed: ", timePassed, "wasTabClosed", wasTabClosed, "URL:", active_url); 
    if(app != "webex"){
      //window.postMessage({name:'sendpost', 'data':data}, "*"); // ALSO THIS DOES NOT WORK WITH WEBEX      
      //chrome.runtime.sendMessage(editorExtensionId, {name:'sendpost', 'data':data, 'confStarted':confStarted}, (addon_response) => { }) 
      // since cannot retrieve editorExtensionId (maybe modify page via content.js?). So I am just reporting directly to batterylab
      const baseURL = "https://mobile.batterylab.dev:8084" 
      console.log("[inject] testing post ") 
      const curr_url = baseURL + "/addonstatus"; 
      // correct uid and videoconf_id with "inject" keywod
      data["uid"] = "inject"
      data["videoconf_id"] = "inject"
      fetch(curr_url, {     
          method: "POST",             
          body: JSON.stringify(data),             
          headers: {
              "Content-type": "application/json;"
          }
      }) 
      .then(function (response) {
        console.log("[inject] data successfully posted!", response);
      })
      .catch(function (err) {
          console.log(" [inject] something went wrong with POST"); 
      });      
      ///////////////////////////////////////////
    } else {      
      full_key = full_key.concat(key_to_send);
      full_data = full_data.concat(data_to_send);           
      if (timePassed >= DUMP_INT && !wasDumped){
        lastDump = Date.now(); 
        console.log("Time to dump for webex", timePassed)
        if(wasTabClosed){
          console.log("Detected a closed tab")          
        }
        var webexData = {
          "app"         : app,
          "timestamp"   : Date.now(),
          "webrtc-data" : full_data
        }
        var pom = document.createElement('a');
        pom.setAttribute('href', 'data:text/plain;charset=utf-8,' + JSON.stringify(webexData));        
        pom.setAttribute('id', 'webrtc');
        var filename = 'webex-' + Date.now() + '.data'
        pom.setAttribute('download', filename);
        pom.click();
        full_key = [];
        full_data = [];    
        
      }
    }

    // if we are done, tell user to hang up (webex) or close the tab (zoom/meet)
    if (timePassed >= DUMP_INT && !wasDumped){ 
      wasDumped = true;        
      lastDump = Date.now(); 
      if(app == "webex"){
        alert("👍 If requested, accept the file download. Then hang up the call, close the tab, and return to the addon 👍")
      } else {        
        if (app == "zoom") {
          var node = document.querySelector('[class="zmu-btn footer__leave-btn ax-outline ellipsis zmu-btn--danger zmu-btn__outline--blue"]');
          if(node !== null){
            console.log("Found node <<Leave>> - click.")
            node.click();
          }
          node = document.querySelector('[class="zmu-btn leave-meeting-options__btn leave-meeting-options__btn--default leave-meeting-options__btn--danger zmu-btn--default zmu-btn__outline--white"]');
          if(node !== null){
            console.log("Found node <<Leave>> interstitial - click.")
            node.click();
          }
        } else if (app == "meet"){
          setTimeout(function() { alert("👍 You can now close the tab, and return to the addon 👍"); }, 2000);
          chrome.runtime.sendMessage(editorExtensionId, {name:'stoppost'}, (addon_response) => {
            console.log("[sendpost-inject.js] Response received", addon_response);
          })
          //var close = document.querySelector('[class="google-material-icons VfPpkd-kBDsod r6Anqf"]');  
          var close = document.querySelector('[aria-label="Leave call" ]');  
          if (close !== null){
            console.log("Found node <<Leave>> - click.")
            close.click();         
          }
        }        
      }
    }

    // // attempt to close for webex? Not a good idea, cause message will disappear too (if it works)
    // if (timePassed >= (DUMP_INT + 10 && app == "webex"){
    //   console.log("Attempt to close window for webex?")
    //   window.close();
    // }
  }

  // transforms a maplike to an object. Mostly for getStats +
  // JSON.parse(JSON.stringify())
  function map2obj(m) {
    if (!m.entries) {
      return m;
    }
    var o = {};
    m.forEach(function(v, k) {
      o[k] = v;
    });
    return o;
  }


  // // page unload (when tab is closed -- is this called in presence of a tab switch?)
  // // ISSUE: not useful cause too late anyway. Create issue with double download in webex, so skipping
  // window.addEventListener('unload', () => {
  //   var active_url = window.location.toString();  
  //   console.log("[inject.js] UNLOAD-EVENT for page: ", active_url, "wasDumped", wasDumped)
  //   if(key_to_send !== undefined && !active_url.includes("about:blank")){
  //     sendResults(key_to_send, data_to_send, true);
  //   } else {
  //     console.log("[inject.js] Skipping sendResults. Nothing to send. Potentially interstitial page. URL: ", active_url); 
  //   }
  // });

  // identify RTCPeerConnection and then append listeners 
  var id = 0;
  var origPeerConnection = window.RTCPeerConnection;
  if (!origPeerConnection) {
    console.log("no peerconnection")
    return; // can happen e.g. when peerconnection is disabled in Firefox.
  }
  window.RTCPeerConnection = function() {
    var pc = new origPeerConnection(arguments[0], arguments[1]);
    pc._id = id++;
    trace('create', pc._id, arguments);

    pc.addEventListener('icecandidate', function(e) {
      trace('onicecandidate', pc._id, e.candidate);
    });
    pc.addEventListener('addstream', function(e) {
      trace('onaddstream', pc._id, e.stream.id + ' ' + e.stream.getTracks().map(function(t) { return t.kind + ':' + t.id; }));
    });
    pc.addEventListener('removestream', function(e) {
      trace('onremovestream', pc._id, e.stream.id + ' ' + e.stream.getTracks().map(function(t) { return t.kind + ':' + t.id; }));
    });
    pc.addEventListener('track', function(e) {
      trace('ontrack', pc._id, e.track.kind + ':' + e.track.id + ' ' + e.streams.map(function(s) { return 'stream:' + s.id; }));
    });
    pc.addEventListener('signalingstatechange', function() {
      trace('onsignalingstatechange', pc._id, pc.signalingState);
    });
    pc.addEventListener('iceconnectionstatechange', function() {
      trace('oniceconnectionstatechange', pc._id, pc.iceConnectionState);
    });
    pc.addEventListener('icegatheringstatechange', function() {
      trace('onicegatheringstatechange', pc._id, pc.iceGatheringState);
    });
    pc.addEventListener('negotiationneeded', function() {
      trace('onnegotiationneeded', pc._id, {});
    });
    pc.addEventListener('datachannel', function(event) {
      trace('ondatachannel', pc._id, [event.channel.id, event.channel.label]);
    });

    window.setTimeout(function poll() {
      if (pc.signalingState !== 'closed') {
        window.setTimeout(poll, 3000);
      }
      pc.getStats()
      .then(function(stats) {
        trace('getStats', pc._id, map2obj(stats));
      });
    }, 3000);
    return pc;
  };
  window.RTCPeerConnection.prototype = origPeerConnection.prototype;

  ['createOffer', 'createAnswer'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        var args = arguments;
        var opts;
        if (arguments.length === 1 && typeof arguments[0] === 'object') {
          opts = arguments[0];
        } else if (arguments.length === 3 && typeof arguments[2] === 'object') {
          opts = arguments[2];
        }
        trace(method, pc._id, opts);
        return new Promise(function(resolve, reject) {
          nativeMethod.apply(pc, [
            function(description) {
              trace(method + 'OnSuccess', pc._id, description);
              resolve(description);
              if (args.length > 0 && typeof args[0] === 'function') {
                args[0].apply(null, [description]);
              }
            },
            function(err) {
              trace(method + 'OnFailure', pc._id, err.toString());
              reject(err);
              if (args.length > 1 && typeof args[1] === 'function') {
                args[1].apply(null, [err]);
              }
            },
            opts,
          ]);
        });
      };
    }
  });

  ['setLocalDescription', 'setRemoteDescription', 'addIceCandidate'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        var args = arguments;
        trace(method, pc._id, args[0]);
        return new Promise(function(resolve, reject) {
          nativeMethod.apply(pc, [args[0],
            function() {
              trace(method + 'OnSuccess', pc._id);
              resolve();
              if (args.length >= 2) {
                args[1].apply(null, []);
              }
            },
            function(err) {
              trace(method + 'OnFailure', pc._id, err.toString());
              reject(err);
              if (args.length >= 3) {
                args[2].apply(null, [err]);
              }
            }]
          );
        });
      };
    }
  });

  ['addStream', 'removeStream'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        var stream = arguments[0];
        var streamInfo = stream.getTracks().map(function(t) {
          return t.kind + ':' + t.id;
        });

        trace(method, pc._id, stream.id + ' ' + streamInfo);
        return nativeMethod.apply(pc, arguments);
      };
    }
  });

  ['addTrack'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        var track = arguments[0];
        var streams = [].slice.call(arguments, 1);
        trace(method, pc._id, track.kind + ':' + track.id + ' ' + (streams.map(function(s) { return 'stream:' + s.id; }).join(';') || '-'));
        var sender = nativeMethod.apply(pc, arguments);
        if (sender && sender.replaceTrack) {
          var nativeReplaceTrack = sender.replaceTrack;
          sender.replaceTrack = function(withTrack) {
            trace('replaceTrack', pc._id,
                (sender.track ? sender.track.kind + ':' + sender.track.id : 'null') +
                ' with ' +
                (withTrack ?  withTrack.kind + ':' + withTrack.id : 'null'));
            return nativeReplaceTrack.apply(sender, arguments);
          }
        }
        return sender;
      };
    }
  });

  ['removeTrack'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        var track = arguments[0].track;
        trace(method, pc._id, track ? track.kind + ':' + track.id : 'null');
        return nativeMethod.apply(pc, arguments);
      };
    }
  });

  ['close', 'createDataChannel'].forEach(function(method) {
    var nativeMethod = window.RTCPeerConnection.prototype[method];
    if (nativeMethod) {
      window.RTCPeerConnection.prototype[method] = function() {
        var pc = this;
        trace(method, pc._id, arguments);
        return nativeMethod.apply(pc, arguments);
      };
    }
  });

  function dumpStream(stream) {
    return {
      id: stream.id,
      tracks: stream.getTracks().map(function(track) {
        return {
          id: track.id,                 // unique identifier (GUID) for the track
          kind: track.kind,             // `audio` or `video`
          label: track.label,           // identified the track source
          enabled: track.enabled,       // application can control it
          muted: track.muted,           // application cannot control it (read-only)
          readyState: track.readyState, // `live` or `ended`
        };
      }),
    };
  }
  var origGetUserMedia;
  var gum;
  if (navigator.getUserMedia) {
    origGetUserMedia = navigator.getUserMedia.bind(navigator);
    gum = function() {
      var id = Math.random().toString(36).substr(2, 10);
      trace('getUserMedia', id, arguments[0]);
      var cb = arguments[1];
      var eb = arguments[2];
      origGetUserMedia(arguments[0],
        function(stream) {
          // we log the stream id, track ids and tracks readystate since that is ended GUM fails
          // to acquire the cam (in chrome)
          trace('getUserMediaOnSuccess', id, dumpStream(stream));
          if (cb) {
            cb(stream);
          }
        },
        function(err) {
          trace('getUserMediaOnFailure', id, err.name);
          if (eb) {
            eb(err);
          }
        }
      );
    };
    navigator.getUserMedia = gum.bind(navigator);
  }
  if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
    origGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
    gum = function() {
      var id = Math.random().toString(36).substr(2, 10);
      trace('navigator.mediaDevices.getUserMedia', id, arguments[0]);
      return origGetUserMedia.apply(navigator.mediaDevices, arguments)
      .then(function(stream) {
        trace('navigator.mediaDevices.getUserMediaOnSuccess', id, dumpStream(stream));
        return stream;
      }, function(err) {
        trace('navigator.mediaDevices.getUserMediaOnFailure', id, err.name);
        return Promise.reject(err);
      });
    };
    navigator.mediaDevices.getUserMedia = gum.bind(navigator.mediaDevices);
  }
})();