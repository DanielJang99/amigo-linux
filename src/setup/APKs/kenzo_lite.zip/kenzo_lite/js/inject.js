document.addEventListener('DOMContentLoaded', function() {
  // https://stackoverflow.com/questions/9515704/access-variables-and-functions-defined-in-page-context-using-a-content-script
    chrome.storage.local.get(["addonId"]).then((result) => {
      var script = document.createElement('script');
      script.src = chrome.runtime.getURL('js/inject-listeners.js');
      ( document.head || document.documentElement).appendChild(script);
      script.dataset.params = JSON.stringify({"addonId": result.addonId});
      script.onload = function() {this.remove();};
  });
});