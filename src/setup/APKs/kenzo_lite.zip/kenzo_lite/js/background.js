(function () {  

  // helper to wait a certain amount of ms 
  function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }
  
  // function triggered when a network request is completed 
  let onCompleted = function(details) {       
    // ignore requests to fast.com and batterylab
    if(details.url.includes('batterylab') || details.url.includes('fast.com')){
      console.log("Ignore logging of traffic to batterylab and fast.com:", details.url )
      return
    }
  };


  chrome.webRequest.onCompleted.addListener(onCompleted, {urls: ['http://*/*', 'https://*/*']}, ["responseHeaders"]) 
  
  // listen to messages from content.js script
  chrome.runtime.onMessage.addListener((message, sender, senderResponse) => {
    if (message['name'] == 'youtube'){
      console.log("RECEIVED ", message['name'], " DATA:", message['msg']) 
      let reqHeaders = new Headers();
      reqHeaders.append('Content-Type', 'text/plain');
      let initObject = {
        method: 'GET', 
        headers: reqHeaders,
      };
      const flink = "file:///storage/emulated/0/Android/data/com.kiwibrowser.browser/files/Download/uid.txt"
      fetch(flink, initObject)
        .then(function(res) {
          let decoder = new TextDecoder('utf-8');
          const reader = res.body.getReader();
          reader.read().then(function(result){
            const val = decoder.decode(result.value);
            const val_splt = val.split('\t');
            const uid = val_splt[0];
            const physical_id = val_splt[1].replace('\n', "");
            var data = {
              "uid": uid, 
              "physical_id": physical_id, 
              "statsForNerds": message['msg'],  
              "timestamp": Date.now()
            }
            const post_url = "https://mobile.batterylab.dev:8082/statsfornerds"
            console.log(data);
            fetch(post_url, {
              method: "POST", 
              body: JSON.stringify(data), 
              headers: {
                "Content-type": "application/json; utf-8"
              }
            })
            .then(function(response) {
              console.log("Stats for Nerds successfully posted!")
            })
          })
      })
        .catch(function (err) {
        console.log(err);
      });
      chrome.webRequest.onCompleted.removeListener(onCompleted);
    }    
    return true;
  })
})

();
