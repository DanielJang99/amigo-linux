// helper functions to manage drag and drop 
function dropHandler(ev) {
  console.log('File(s) dropped');

  // Prevent default behavior (Prevent file from being opened)
  ev.preventDefault();

  if (ev.dataTransfer.items) {
    // Use DataTransferItemList interface to access the file(s)
    for (var i = 0; i < ev.dataTransfer.items.length; i++) {
      // If dropped items aren't files, reject them
      if (ev.dataTransfer.items[i].kind === 'file') {
        var file = ev.dataTransfer.items[i].getAsFile();
        console.log('File:' + file.name);
        var data; 
        var reader = new FileReader();
          reader.onloadend = function(e) {
          data = JSON.parse(this.result);
          console.log("==>", userID, videoconfID)    
          data["uid"] = userID; 
          data["videoconf_id"] = videoconfID; 
          data["timestamp"] = Date.now();
          console.log(data);
          fetch(baseUrl, {
            method: "POST", 
            headers: {"Content-type": "application/json"}, 
            body: JSON.stringify(data)
          })
          .then((response)=> {
            if(response.ok){
              console.log("POST-RET-CODE:", response.status);
              return response.json();
            }else{
              throw new Error("Request failed with status: " + response.status);
            }
          }).then((addon_response) => {
            console.log("[webexupload] Response received", addon_response);
            chrome.runtime.sendMessage({ name: 'webexupload' }, () => {
              console.log("Message sent to background script");
              location.reload(); // Refresh the page
            });
          })
          .catch(e => {
            console.log("Request failed with error: ", e);
          })
        };
        reader.readAsText(file);        
        ///////////////////
      } else {
        console.log("Rejected. Not a file!"); 
      }
    }
  } else {
    // Use DataTransfer interface to access the file(s)
    for (var i = 0; i < ev.dataTransfer.files.length; i++) {
      console.log('... file[' + i + '].name = ' + ev.dataTransfer.files[i].name);
    }
  }
}

function dragOverHandler(ev) {
  // Prevent default behavior (Prevent file from being opened)
  ev.preventDefault();
}


// helper function to load a JSON file and post to our server
function loadFile() {
    var input, file, fr;

    if (typeof window.FileReader !== 'function') {
      alert("The file API isn't supported on this browser yet.");
      return;
    }

    input = document.getElementById('fileinput');
    if (!input) {
      alert("Um, couldn't find the fileinput element.");
    }
    else if (!input.files) {
      alert("This browser doesn't seem to support the `files` property of file inputs.");
    }
    else if (!input.files[0]) {
      alert("Please select a file before clicking 'Load'");
    }
    else {
      file = input.files[0];
      fr = new FileReader();
      fr.onload = receivedText;
      fr.readAsText(file);
    }

    function receivedText(e) {
      let lines = e.target.result;
      var data = JSON.parse(lines); 
      console.log(data);
      data["uid"] = userID; 
      data["videoconf_id"] = videoconfID; 
      data["timestamp"] = Date.now();      
      fetch(baseUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => {
          if (response.ok) {
            console.log("POST-RET-CODE:", response.status);
            return response.json();
          } else {
            throw new Error("Request failed with status: " + response.status);
          }
      })
      .then((addon_response) => {
        console.log("[webexupload] Response received", addon_response);
        chrome.runtime.sendMessage({ name: 'webexupload' }, () => {
          console.log("Message sent to background script");
          location.reload(); // Refresh the page
        });
      })
      .catch((error) => {
        console.log("Request failed with error:", error);
      });
    }
  }

// helper function to update code to be redeemed
function update_code() {
  console.log("Contacting our database to get a new code");
  const url = `https://mobile.batterylab.dev:8084/code?uid=${userID}&vrs=${vrs}`;
  fetch(url, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    },
  })
  .then(response => response.json())
  .then(data => {
    const myCode = data.code;
    console.log("Server response. Code:", myCode);
    console.log("Updating code to:", myCode);
    
    // Inform background of the code to stop future addon usage
    chrome.runtime.sendMessage({'name': 'code', 'code': myCode}, (response) => {
      console.log("Background.js responded to updatecode");
    });
  })
  .catch(error => {
    console.error("Error contacting the server:", error);
  });
}

// simple helper to hide GUI elements not needed 
function hide_not_needed_gui(){
  document.getElementById('payment-instructions').style.display = "none"; 
  document.getElementById('payment').style.display = "none";  
  document.getElementById('fileinput').style.display = "none";   
  document.getElementById('btnLoad').style.display = "none";
  document.getElementById('drop_zone').style.display = "none";  
  document.getElementById('thumbsup').style.display = "none";
}

// helper function to update info and button visibility 
function update_buttons(experiments, meetings){  
  // local params
  var isSelected = false; 
  
  // add default options to server status
  var face = document.getElementById("status"); 
  face.classList.add('fa-solid')
  face.classList.add('fa-xl')

  // get generic button and instructions
  var elem = document.getElementById('generic');
  var instructions = document.getElementById('instructions');  
  
  // // check if meetings are ready or not 
  var sadFace = false; 

  // var sadFace = true; 
  // if (meetings['zoom'] !== undefined && meetings['zoom'] !== null){
  //   sadFace = false;
  // }
  // if (meetings['meet'] !== undefined && meetings['meet'] !== null){
  //   sadFace = false;
  // }
  // if (meetings['webex'] !== undefined && meetings['webex'] !== null){
  //   sadFace = false;
  // }
  // if (meetings['starlink'] !== undefined && meetings['starlink'] !== null){
  //   sadFace = false;
  // }  
  // if (meetings['youtube'] !== undefined && meetings['youtube'] !== null){
  //   sadFace = false;
  // }

  // check the potential MAX_BROWSING tests
  console.log(meetings)
  for (let i = 0; i < MAX_BROWSING; i++) {  
    const browser_key = "browser-" + i.toString();
    if (meetings[browser_key] !== undefined && meetings[browser_key] !== null){
      sadFace = false;
    }
  }
  // show clocksync experiment 
  // clockSync = true
  // if (clockSync){
  //   if (!experiments.hasOwnProperty("sync")){
  //     face.classList.add('fa-face-smile');    
  //     elem.setAttribute('href', 'https://time.is');   
  //     elem.innerText = "SYNC";    
  //     instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li> Click the above button.</li> <li> A new tab will open running a time sync.</li> <li> close the tab when the page load and return to the addon.</li></ol>";
  //     instructions.style.fontSize = "20px";
  //     isSelected = true;
  //     hide_not_needed_gui()
  //     console.log("Addon will show time sync");
  //     return
  //   }
  // }

  
  // check if speedtest should and can be shown 
  // NOTE: we currently allows speedtest even if servers are down (since started on demand)
  var needSpeedTest = true;   
  if (needSpeedTest){
    //console.log("Checking speedtest -- isSelected:", isSelected) 
    if (!experiments.hasOwnProperty("fast")){
      face.classList.add('fa-face-smile');    
      elem.innerText = "SPEEDTEST";    
      elem.setAttribute('href', 'https://fast.com');   
      instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li> Click the above button.</li> <li> A new tab will open running a speedtest.</li> <li> Wait for the speedtest to complete, and a message on screen saying you can close the tab (about one minute).</li> <li> Close the tab and return to the addon.</li></ol>";
      instructions.style.fontSize = "20px";
      isSelected = true;
      hide_not_needed_gui()
      console.log("Addon will show spedtest");
      return
    }
  }

  // zoom 
  if (experiments["zoom"] === undefined && meetings['zoom'] !== null){ 
    isSelected = true;
    elem.setAttribute('href', meetings['zoom']); 
    elem.innerText = "ZOOM";
    //instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li> Click the above button.</li> <li> A new tab will open launching Zoom.</li> <li> Type your name and password \"abc\".</li> <li> Join the call until a popup message says to hang up. <li> Close the tab and return to the addon.</li></ol>";
    //instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li> Click the above button.</li> <li> A new tab will open launching Zoom.</li> <li> Enter a name and join the call. If the call is not ready, please wait.</li> <li> Stay on the call until a message on screen says to hang up<br> (~90 sec). <li> Close the tab and return to the addon.</li></ol>";
    instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li> Click the above button.</li> <li> A new tab will open launching Zoom.</li> <li> Enter a name and join the call. If the call is not ready, please wait.</li> <li> Stay on the call until it automatically ends (~90 sec). <li> Close the tab and return to the addon.</li></ol>";    
    instructions.style.fontSize = "20px";    
    hide_not_needed_gui()
    console.log("Addon will show zoom");    
    return
  }
  
  // switch between happy face or not (for server status)
  if(sadFace){
    face.classList.add('fa-face-frown');
  } else {
    face.classList.add('fa-face-smile');
  } 

  // hide other GUI elements and stop here in case servers are still not ready
  if (sadFace){
    hide_not_needed_gui()    
    instructions.innerHTML = "<ol><b>Something is wrong with our server. Please retry later. To retry simply close/open the addon by tapping on it.</ol></b>";
    instructions.style.fontSize = "20px";
    elem.style.display = "none";
    return
  }

  // N browser experiments if needed 
  for (let i = 0; i < MAX_BROWSING; i++) {  
    const browser_key = "browser-" + i.toString();
    console.log('=>', meetings[browser_key])      
    if (experiments[browser_key] === undefined && meetings[browser_key] !== undefined){
      elem.setAttribute('href', meetings[browser_key]);
      elem.innerText = "BROWSE-" + i.toString();
      instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Click the above button.</li> <li> A new tab will open launching a website.</li> <li> Wait for the page to load and a message on screen saying you can close the tab.</li> <li> Close the tab and return to the addon.</li></ol>";
      instructions.style.fontSize = "20px";    
      hide_not_needed_gui()
      isSelected = true;
      console.log("Addon will show browser experiment");
      return
    }
  }

  // YouTube experiment if needed 
  if (experiments["youtube"] === undefined && meetings['youtube'] !== undefined){
    elem.setAttribute('href', meetings['youtube']);
    elem.innerText = "YOUTUBE";
    instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Click the above button.</li> <li> A new tab will open launching youtube.</li> <li> Watch the video and wait for a message on screen saying you can close the tab (about one minute).</li> <li> Close the tab and return to the addon.</li></ol>";
    instructions.style.fontSize = "20px";    
    hide_not_needed_gui()
    isSelected = true;
    console.log("Addon will show youtube experiment");
    return
  } 

  // meet 
  if (experiments["meet"] === undefined && meetings['meet'] !== null){     
    elem.setAttribute('href', meetings['meet']);  
    elem.innerText = "MEET";
    //instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b> <li><u>Make sure you are logged in with your Google account. </u> </li><li> Click the above button.</li> <li> A new tab will open where you can join a Meet call.</li> <li> Stay on the call until a message on screen says to hang up<br>(~90 sec). </li> <li> Close the tab and return to the addon.</li></ol>";  
    // It seems no more need to be logged in with Google account? 
    //<li><u>Make sure you are logged in with your Google account. </u> </li><li> 
    instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li>  Click the above button.</li> <li> A new tab will open where you can join a videoconference.</li> <li> If requested, provide a name and ask to join. </li> <li> Stay on the call until it automatically ends (~90 sec). </li> <li> Close the tab and return to the addon.</li></ol>";  
    instructions.style.fontSize = "20px";    
    isSelected = true;
    hide_not_needed_gui()
    console.log("Addon will show meet");    
    return
  }  
 
  // webex
  if (experiments["webex"] === undefined && meetings['webex'] !== null){       
    elem.setAttribute('href', meetings['webex']);
    elem.innerText = "WEBEX";
    instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Click the above button.</li> <li> A new tab will open launching Webex.</li> <li> Type your name, solve the CAPTCHA, and join the call. </li> <li> Stay on the call until a message on screen says to hang up<br> (~90 sec) and <u> a file is downloaded.</u> </li> <li> Close the tab and return to the addon.</li></ol>";  
    instructions.style.fontSize = "20px";    
    hide_not_needed_gui()
    isSelected = true;
    console.log("Addon will show webex");
    return
  } 

  // webex upload
  if (experiments["webex"] !== undefined  && experiments["webexupload"] === undefined){ 
    console.log("User did not upload yet the webex logs")
    document.getElementById('payment-instructions').style.display = "none"; 
    document.getElementById('payment').style.display = "none";    
    document.getElementById('thumbsup').style.display = "none";
    instructions.style.fontSize = "20px";
    if (!useUpload){
      instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Drag and drop in the box below the file (webex-*) from the Download window which was automatically opened.</li></ol>";      
      document.getElementById('fileinput').style.display = "none";   
      document.getElementById('btnLoad').style.display = "none";
      console.log("Asking to show download folder...")
      chrome.runtime.sendMessage({name:'show'}, (addon_response) => {
        console.log("[show] Response received", addon_response);  
      });
    }else {
      elem.style.display = "none"; 
      instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Wait for the message on screen saying you can hang up (~90 sec)</li> <li>Use the button below to select the file downloaded at the end of the test. The file (webex-*) is located in your browser default download folder.</li> <li> Click \"Upload\"</li></ol>";
      document.getElementById('drop_zone').style.display = "none";           
    }     
    return
  }

  // starlink experiment if needed 
  if (experiments["starlink"] === undefined && meetings['starlink'] !== null){
    elem.setAttribute('href', meetings['starlink']);
    elem.innerText = "STARLINK";
    instructions.innerHTML = "<ol><b>INSTRUCTIONS:</b><li> Click the above button.</li> <li> A new tab will open launching the Starlink statistics page.</li> <li> Wait for a message on screen saying you can close the tab.</li> <li> Close the tab and return to the addon.</li></ol>";
    instructions.style.fontSize = "20px";    
    hide_not_needed_gui()
    isSelected = true;
    console.log("Addon will show starlink page");
    return
  } 

  // if here no experiment to show (either not connected or all done) -- Q: is this code needed? 
  elem.style.display = "none";   
  console.log("Time to show the payment stuff"); 
  instructions.style.display = "none";
  document.getElementById('fileinput').style.display = "none";   
  document.getElementById('btnLoad').style.display = "none";
  document.getElementById('drop_zone').style.display = "none";    
  console.log("Making payment code visible - CurrentCode:", myCode);       
  if (myCode === "") { 
    update_code()
  }        
  
  // show city form and hide the rest 
  document.getElementById('city_descr').style.display = "block";                
  document.getElementById('city_name').style.display  = "block";    
  document.getElementById('citySubmit').style.display = "block"
  document.getElementById('progress_descr').style.display = "none";
  document.getElementById('myProgress').style.display = "none"; 
  hide_not_needed_gui()
}

// update time left for RTT measurement
function setTime() {
  tPassed = (Date.now() - RTT_launch)/1000;
  if (tPassed > RTT_DURATION){
    console.log("Time to stop setTime")
    clearInterval(interval);    
    location.reload();
  } else{ 
    var face = document.getElementById("status"); 
    face.classList.add('fa-solid')
    face.classList.add('fa-xl')
    face.classList.add('fa-face-grin-beam-sweat');
    var timeLeft = parseInt(RTT_DURATION - tPassed); 
    timesRun += 1;       
    var elem = document.getElementById('generic');
    elem.style.display = "none";
    var instructions = document.getElementById('instructions');    
    instructions.innerHTML = "<ol><b>We are warming up our servers. Experiments will start in <font color=\"blue\">  " + timeLeft + "</font> secs.</ol></b>";
    instructions.style.fontSize = "20px";   
  
    // hide elements not needed
    hide_not_needed_gui()
  }
}

// general parameters 
var meetings = {}             // dictionary of experiments to be run 
//var url = "https://mobile.batterylab.dev:8084/action"; // default url at batterylab (used)
var time_passed = 0           // test duration 
var num_tests = 0             // number of experiments to run 
var TEST_DURATION = 120       // each test should last at least 120 seconds
var NUM_APPS = 4              // we are testing speedtest + 3 clients: zoom, meet, webex
var myCode = "";              // payment code
var useUpload = true;         // control if to show upload button or not for webex 
var timesRun = 0              // keep track of how many RTT experiments were run so far 
var interval;                 // set time interval 
var userID;                   // keep track of user identifier 
var videoconfID;              // id of current videosession
var RTT_launch;               // keep track of when RTT measurement was started 
var RTT_DURATION = 35;        // time needed to measure RTT and allow VMs to load
var CALL_DURATION = 88000;    // default videoconference duration (granting two seconds from the 90)
var MAX_BROWSING = 5          // maximum number of URLs to be tested 
var showWeather = true        // flag to control if to show weather information or not 
var citySubmitted = false;    // flag to keep track if city was submitted or not 
var MAX_YOUTUBE = 10000;      // max duration of youtube data collection (msec)
var MAX_SPEEDTEST_DUR = 45;   // max duration of a speedtest (sec) => will then be converted in ms
var BROWSING_TIMEOUT = 30000; // max duration allowed for browser page load time event
var isDebugging = true;       // flag to control if we are debugging or not     
var vrs = ''                  // addon version installed 

// wait for addon to be ready 
$(document).ready(function() {
  console.log("discover init", Date.now());
  // get experiment status from the background script
  var duration = 0; 
  chrome.runtime.sendMessage({name:'getinfo'}, (addon_response) => {
    console.log("[getinfo] Response received", addon_response);

    // learn settings from background script  
    MAX_YOUTUBE = addon_response['MAX_YOUTUBE']
    MAX_SPEEDTEST_DUR = addon_response['MAX_SPEEDTEST_DUR'] * 1000
    BROWSING_TIMEOUT = addon_response['BROWSING_TIMEOUT']
    isDebugging = addon_response['isDebugging'] 
    vrs = addon_response['vrs']
    console.log("====>", BROWSING_TIMEOUT)

    // always update tester ID and code version 
    document.getElementById('version').innerHTML = "<b>VRS:</b> " + vrs + "<br><b>ID: </b>" + addon_response['userid'];
        
    // find main elements to update dynamically
    var instructions = document.getElementById('instructions');  
    var face = document.getElementById('status'); 
    var elem = document.getElementById('generic');      

    // switch between being done and not
    if(addon_response['success'] === false){
      myCode =  addon_response['myCode'];
      citySubmitted = addon_response['citySubmitted'];
      elem.style.display = "none"; 
      document.getElementById("myBar").style.width = "100%";       
      face.classList.add('fa-solid')
      face.classList.add('fa-xl')
      face.classList.add('fa-face-smile');
      instructions.style.display = "none";
      document.getElementById('fileinput').style.display = "none";   
      document.getElementById('btnLoad').style.display = "none";
      document.getElementById('drop_zone').style.display = "none";    
      document.getElementById("payment").innerText = myCode; 
      document.getElementById("payment").style.fontSize = "25px";
      document.getElementById("payment-instructions").style.fontSize = "25px";
      
      // hide progress bar when asking for city information
      if(citySubmitted === false){
        document.getElementById('progress_descr').style.display = "none";
        document.getElementById('myProgress').style.display = "none"; 
        hide_not_needed_gui()
      } else {
        document.getElementById('city_descr').style.display = "none";                
        document.getElementById('city_name').style.display = "none";    
        document.getElementById('citySubmit').style.display = "none";
      }
    } else {   
        // show notification if a job on Prolific is available 
        if(addon_response['restart'] === true){         
          Swal.fire({
              icon: "info",
              title: "A Prolific job is ready for you!", 
              text: "If you would like to join: 1) press YES, 2) accept the job on Prolific, return to the addon for instructions!",
              showDenyButton: true,
              showCancelButton: true,
              confirmButtonText: 'Yes',
              denyButtonText: 'No'
            }).then((result) => {
              if (result['isConfirmed']){
                console.log("User said YES")
                chrome.runtime.sendMessage({name:'restart', 'msg':true}, (addon_response) => {})                
              } else {
                console.log("User said NO")                
                chrome.runtime.sendMessage({name:'restart', 'msg':false}, (addon_response) => {})
              }
              location.reload();
            })
        }
      
        // remove request for city (if needed it will be re-added)
        console.log("Remove form info for the city")
        document.getElementById('city_descr').style.display = "none";                
        document.getElementById('city_name').style.display = "none";    
        document.getElementById('citySubmit').style.display = "none";                            
        
        // check if servers are down
        console.log("Server status:", addon_response['ServerStatus'])
        if (addon_response['ServerStatus'] === 'down'){
          hide_not_needed_gui()    
          face.classList.add('fa-solid')
          face.classList.add('fa-xl')
          face.classList.add('fa-face-frown');  
          instructions.innerHTML = "<ol><b>Something is wrong with our server. Please retry later. To retry simply close/open the addon by tapping on it.</ol></b>";
          instructions.style.fontSize = "20px";
          elem.style.display = "none";          
          document.getElementById('progress_descr').style.display = "none";
          document.getElementById('myProgress').style.display = "none";                    
        } // when servers are up, do the following
        else {
          if (addon_response['meetings'] !== undefined && addon_response['experiments'] !== undefined){
            console.log("=>", addon_response['experiments'])
            for (var key in addon_response['experiments']){
              if (key == 'webexupload' || key == 'restart'){ // webexupload and restart are not experiments
                continue;
              }
              // count how many experiments will be done (and duration so far - unused)
              if (addon_response['experiments'][key] !== null){
                num_tests += 1 
                duration +=  addon_response['experiments'][key]
              }
            }
            duration /= 1000 // ms => sec
            meetings = addon_response['meetings']
            console.log("ExpStatus:", addon_response['experiments'])
            console.log("Num test: ", num_tests, "Duration:",  duration)
            console.log("MeetingsIDs:", meetings)

            // compute delta per experiment 
            denom = 1   // account for speedtest which is not in the list Q: really?
            for (var key in meetings){
              if (meetings[key] !== null){ // && key != 'videoconf_id') { //NOTE: videoconf_id should not be counted
                denom += 1 
                console.log(denom, meetings[key])
              }
            }
            delta = 100/denom
            console.log("denom:", denom, "delta progress", delta)
            console.log(addon_response['experiments'])

            // showing time passed (not used anymore)
            //document.getElementById("time").value = "Test Duration:" + Math.floor(duration) + " sec"; 
            
            // show update bar
            if (addon_response['experiments']['webex'] !== undefined && addon_response['experiments']['webexupload'] === undefined){
              console.log("Reducing progress for webex upload")
              document.getElementById("myBar").style.width = delta * num_tests - 5 + "%";
            } else {
              document.getElementById("myBar").style.width = delta * num_tests + "%";         
            }
            
            // avoid being stuck on RTT while debugging
            if(isDebugging){
              console.log("NOTE: CURRENTLY DISABLED RTT")   
              addon_response['experiments']["RTT"] = "DONE"
            }
            
            // check if we are waiting on RTT 
            if (!addon_response['experiments'].hasOwnProperty("RTT")){ 
              if (addon_response['RTT_launch'] !== undefined){
                RTT_launch = addon_response['RTT_launch']
                console.log("RTT_launch:", RTT_launch)
              } else {
                RTT_launch = Date.now(); 
              }
              setTime(); 
              interval = setInterval(setTime, 1000);
            } else {
              // remove request for city information (done as last step) 
              document.getElementById('city_descr').style.display = "none";                
              document.getElementById('city_name').style.display = "none";                               
              
              // update userID and videoconfID
              userID = addon_response['userid']
              videoconfID = addon_response['videoconfid']

              // inform users on how much time is left during a task (or if they left too early)
              lastApp = addon_response['LastApp']
              launch_time = addon_response['LaunchTime']
              duration_last = Date.now() -  launch_time;               
              
              // add extra time, just in case (duration somehow depends on user behavior)              
              var time_check = CALL_DURATION + 15000;  
              if(lastApp == 'youtube'){
                time_check = MAX_YOUTUBE + 10000
              } else if (lastApp.includes('browser')){
                time_check = BROWSING_TIMEOUT
                if(addon_response['experiments'][lastApp] !== undefined){
                  console.log(lastApp, " was correctly completed!")
                  time_check = 0
                }
              } else if (lastApp == 'fast'){ 
                time_check = MAX_SPEEDTEST_DUR
                if(addon_response['experiments']['fast'] !== undefined){
                  console.log("Fast was correctly completed!")
                  time_check = 0
                }
              } else if(lastApp == "starlink"){ //||  lastApp == 'fast'){
                  time_check = 5000; 
              }
            
              // logging 
              console.log("APP:", lastApp, "LaunchTime:", launch_time, "TimeOnTask:", duration_last, "MaxDuration:", time_check);                
              
              //NOTE: time for webex is hard
              // !isDebugging && 
              if (lastApp != 'webex' && duration_last < time_check){   
                var time_left = Math.ceil((time_check - duration_last)/1000)
                hide_not_needed_gui()    
                face.classList.add('fa-solid')
                face.classList.add('fa-xl')
                face.classList.add('fa-face-smile');  
                instructions.innerHTML = "<ol><b>⚠️ ⚠️ ⚠️ ⚠️ ⚠️ ⚠️<br> Please, stay on the tab until a message on screen indicates the task is done. Then close the tab and return here for instructions. <br>⚠️ ⚠️ ⚠️ ⚠️ ⚠️ ⚠️ <br><br><br>Approx. Time left:<font color=\"blue\">" + time_left + "</font> secs <br></ol></b>";
                instructions.style.fontSize = "20px";
                elem.style.display = "none";
              } else {
                // add URLs to buttons and hide if already tested
                update_buttons(addon_response['experiments'], meetings);
              }
            }
          } else {
            console.log("[getinfo] Response received was undefined");
            face.classList.add('fa-solid')
            face.classList.add('fa-xl')
            face.classList.add('fa-face-frown');  
            hide_not_needed_gui()    
            elem.style.display = "none";
            document.getElementById("time").value = "Test Duration: 0 sec"; 
          }
        }
    }     
})

  // drag/drop for webex file listeners
  $('#drop_zone')
    // crucial for the 'drop' event to fire
    .on('dragover', false) 
    .on('drop', function (event) {
        console.log("OnDrop detected")
        if(event === undefined){
          console.log("drop-event is NULL")
        } else { 
          dropHandler(event.originalEvent)
        }
    });  
  $("#drop_zone").on("dragover", function(event) {   
    //console.log("DragOver detected")
    dragOverHandler(event.originalEvent)
  })   
  
  // button to upload webex data 
  $("#btnLoad").click(function() {
    console.log("Clicked btnLoad")
    loadFile()
  }) 

  // button to upload webex data 
  $("#citySubmit").click(function() {
    var city = document.getElementById('city_name').value;
    console.log("Clicked citySubmit. Length provided:", city.length);
    if (city.length >= 5){    
      chrome.runtime.sendMessage({'name':'update_city', 'msg':city}, (response) => { 
        location.reload(); 
      })    
    } else {
      alert("Please add the full city and state information..."); 
    }
  }) 

  // // reload an experiment
  // $("#reload").click(function() {
  //   console.log("Clicked on reload, and asked to do so");    
  //   var duration = 0;   
  //   chrome.runtime.sendMessage({name:'reset'}, (addon_response) => {      
  //     console.log("[reset] Response received", addon_response);
  //     for (var key in addon_response['experiments']){
  //       if (addon_response['experiments'][key] !== null){
  //         num_tests += 1 
  //         duration +=  addon_response['experiments'][key]
  //       }
  //     }
  //     duration /= 1000 // convert from ms to seconds
  //     meetings = addon_response['meetings']
  //     console.log("ExpStatus:", addon_response['experiments'])
  //     console.log("Num test: ", num_tests, "Duration:",  duration)
  //     console.log("MeetingsIDs:", meetings);
  //     update_buttons(addon_response['experiments'], meetings);
  //     location.reload();    // refresh the page 
  //   })
  // })

  // reload an experiment
  $("#reload").click(function() {
    console.log("Clicked on reload, and asked to do so"); 
    Swal.fire(
      'Request for a new experiment was sent!',
      'Close the addon and wait for a notification!'
    )
    var duration = 0;   
    chrome.runtime.sendMessage({name:'reset'}, (addon_response) => {
    })
  })

  // inform background to start monitoring things as needed (use button value to decide)
  $("#generic").on("click", function(e) {
    e.preventDefault();
    var textVal = document.getElementById('generic').innerText
    // check the potential MAX_BROWSING tests
    for (let i = 0; i < MAX_BROWSING; i++) {  
      const browser_key = "BROWSE-" + i.toString();
      if (textVal == browser_key){
        app = 'browser-' + i.toString(); 
        break; 
      }
    }
    if (textVal == 'SPEEDTEST'){
      app = 'fast';
    } else if (textVal == 'ZOOM'){
      app = 'zoom';
    } else if (textVal == 'MEET'){
      app = 'meet';
    } else if (textVal == 'WEBEX'){
      app = 'webex';
    } else if (textVal == 'STARLINK'){
      app = 'starlink';
    } else if (textVal == 'YOUTUBE'){
      app = 'youtube';
    }
    console.log("sending updateap for:", app)
    chrome.runtime.sendMessage({name:'updateapp', app:app}, (response) => {  
      console.log("Background.js responded to updateapp -- started monitoring things as well")
      chrome.tabs.create({url: $(this).prop('href')})
    })
  }) 
})

////////////////// scratchpad 
  // // get weather update (FIXME, geolocation info not working)
  // let long;
  // let lat;
  // let key;  
  // if (navigator.geolocation) {
  //   navigator.geolocation.getCurrentPosition((position) => {
  //     console.log("entered getCurrentPosition, yay")
  //     long = position.coords.longitude;
  //     lat = position.coords.latitude;
  //     console.log("=>", long, lat)
  //     key = "7f5806c8f3fd28b03e2d6580a50732d6"
  //     const api = `http://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${long}&appid=${key}`;
  //     fetch(api)
  //       .then((response) => {
  //         return response.json();
  //       })
  //       .then((data) => {
  //         console.log("Weather data", data); 
  //       });
  //   });
  // }


  // relaxing speedtest requirements for completion to avoid user getting stuck
  // FIXME: why not using just MAX_SPEEDTEST_DUR
  // if(addon_response['LastApp'] == 'fast' && addon_response['experiments']['fast'] == undefined){
  //   var time_passed = Date.now() - addon_response['LaunchTime']; 
  //   if (time_passed > 30000){ // CHECK: was 8000. Make sense?
  //     addon_response['experiments']['fast'] = time_passed;
  //   }
  // }

