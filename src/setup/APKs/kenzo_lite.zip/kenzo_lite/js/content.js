// Aravindh Raman helper function for starlink data
var getAllText = function(allDivs) {
    var allTexts = [];
    for (let index = 0; index < allDivs.length; index++) {
        var div = allDivs[index];
        if(div.style.getPropertyValue("font-family") != "") {
            allTexts.push(div.getInnerHTML());
        }
    }

    return allTexts;
}

// Aravindh Raman helper function for starlink data 
var getMetricData = function(allDivs, metricName) {
    var metric = "";
    var time = "";
    for (let index = 0; index < allDivs.length; index++) {
        var currentDiv = allDivs[index];
        if (currentDiv.getInnerHTML().toLowerCase() ==  metricName){
            for (let indexj = index; indexj < allDivs.length; indexj++) {
                var stDiv = allDivs[indexj];
                if (stDiv) {
                    svgDiv = stDiv.getElementsByTagName("svg");
                    if (svgDiv.length > 0) {

                       if (svgDiv[0].getElementsByTagName("mask").length > 0) {
                        var masked = svgDiv[0].getElementsByTagName("mask");
                        metric = masked[0].nextElementSibling.nextElementSibling;
                        time = masked[0].nextElementSibling.nextElementSibling.nextElementSibling;
                        return [metric.attributes.d.value,  time.innerHTML];
                    }
                }
               } 
            }
        }
    }
    return [metric,  time]
}

// Listener for local messages -- used to return youtube results; 
window.addEventListener("message", function(event) {
    // We only accept messages from ourselves
    if (event.source != window)
        return;

    if (event.data.name && (event.data.name == "youtube_stats")) {
        chrome.runtime.sendMessage({'name':'youtube', 'msg':event.data.msg}, (response) => { 
          setTimeout(function() { alert("👍 You can now close the tab, and return to the addon 👍"); }, 1000);
        })
    }
});


// global variables 
var app = ""
var intervalFast;
var intervalStarlink;  
var intervalMaps; 
var intervalScreenshot; 
var alertSent   = false; 
var pressedInfo = false; 
var found = 0; 
var starlink_data = {}; 
var MAX_SPEEDTEST_DUR = 45;    // max duration of a speedtest (sec)
var MAX_YOUTUBE = 10000;       // max duration of youtube data collection (msec)
var launchTime = Date.now();   // script launch time 
var isCollecting = false       // keep tracking if we are already collecting data for browser
var BROWSING_TIMEOUT = 60000;  // max time allowed for browsing onload event 
var intervalReady; 
var micClicked = false; 
var vidClicked = false; 
var MEET_CODE = "yzv-zmyj-mmv"; // last code for Google meet meetings
var CPU_FREQ = 4000


// page loaded event 
window.addEventListener('load', () => {  
  var active_url = window.location.toString();  
  console.log("Loaded page", active_url); 

  // update MAX_YOUTUBE duration 
  chrome.runtime.sendMessage({'name':'get_timer'}, (response) => {
    MAX_SPEEDTEST_DUR = response['MAX_SPEEDTEST_DUR']
    MAX_YOUTUBE = response['MAX_YOUTUBE']
    BROWSING_TIMEOUT = response['BROWSING_TIMEOUT']
    var MEET_URL = "--";
    if (response['MEET_URL'] !== undefined){
      MEET_URL = response['MEET_URL'].split("/");
      MEET_CODE  = MEET_URL.pop();
    }
    console.log("Updating timers. MAX_SPEEDTEST_DUR:", MAX_SPEEDTEST_DUR, "MAX_YOUTUBE:", MAX_YOUTUBE, "BROWSING_TIMEOUT:", BROWSING_TIMEOUT, "MEET_URL:", MEET_URL, "MEET_CODE:", MEET_CODE)
  })
  
  // // googlemaps location idea
  // if (active_url.includes("google") && active_url.includes("maps")){ 
  //   console.log("Found googlemaps. Starting check location each two seconds"); 
  //   intervalMaps = window.setInterval(function(){
  //     check_location();
  //   }, 2000);    
  // }

  // start monitoring html page for fast.com 
  if (active_url.includes("fast")){ 
    intervalFast = window.setInterval(function(){
      dump_screen();
    }, 2000);
    // notify of page load
    chrome.runtime.sendMessage({'name':'load', 'page':active_url}, (response) => {  // check removed "loadtime"
      console.log("LOAD-EVENT -- Response received")        
    })
  } 

  // code related to Web browsing 
  //if(active_url.includes("https://www.reddit.com") || active_url.includes("https://www.cnn.com") || active_url.includes("https://edition.cnn.com") || active_url.includes("https://www.nytimes.com/") || active_url.includes("https://www.washingtonpost.com/") || active_url.includes("https://www.espn.com/") || active_url.includes("https://www.wikipedia.org/") || active_url.includes("http1.akamai.com/") || active_url.includes("http2.akamai.com/")){  
  if(active_url.includes("http1.akamai.com/") || active_url.includes("http2.akamai.com/")){    
    console.log("Detected URL:" + active_url +  " - Start performance metrics collection!");    
    if (isCollecting === false){
      console.log("Started collecting performance data for URL:" + active_url)
      startCollect()
      isCollecting = true 
    }
  }

  // youtube.com specific code 
  if(active_url.includes("youtube") && active_url.includes("TSZxxqHoLzE")){
    console.log("Detected youtube page");

    // // for testing CPU & Screen collection 
    // // https://stackoverflow.com/questions/38373918/web-workers-to-make-setinterval-work-as-normal
    // window.setInterval(function(){
    //   chrome.runtime.sendMessage({'name': 'collect_cpu'}, (response) => {
    //     console.log("COLLECT-CPU -- Response Received");
    // })
    // }, CPU_FREQ);

    // testing 
    appendChild();
    
    function sleep(ms) {
      return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function appendChild() {
        await sleep(9000);

        // append injection needed for youtube
        var script = document.createElement("script");
        script.src = chrome.runtime.getURL('js/inject-youtube.js')
        var script_text = monitorStatsNerds.toString();
        script_text += "var launchTime = Date.now(); var MAX_YOUTUBE =" + MAX_YOUTUBE + "; var youtube_data = []; monitorStatsNerds();";       
        document.body.appendChild(script);
        script.dataset.params = JSON.stringify({"scriptToEval": script_text})
        console.log("append. MAX_YOUTUBE:", MAX_YOUTUBE);
    }
  }

  // partial meet automation (issue when user needs to provide a name)
  // https://meet.google.com/yzv-zmyj-mmv  
  if(active_url.includes("meet") && active_url.includes(MEET_CODE)){
    console.log("Found meet");        
    const name = "tester-" + Math.floor(Math.random() * 50).toString() + " "; 

    // schedule either auto log-in or notification in 20 seconds 
    intervalReady =  window.setInterval(function(){
          fill_meet_info(name);
        }, 20000);
  } 

  // // new code for time.is -- attempt at getting sync info. not working
  // if(active_url.includes("time")){
  //   //var elem = document.getElementById('syncDtl');
  //   var elem = document.getElementById('time_section');
  //   if(elem !== null){
  //     console.log(elem)
  //     chrome.runtime.sendMessage({'name':'time', 'msg':elem}, (response) => {
  //       console.log("OK")       
  //       setTimeout(function() { alert("👍 You can now close the tab, and return to the addon 👍"); }, 1000);
  //     })
  //   }
  // }
});

// page unload (when tab is closed) 
// "unload" event is not recommended. Replaced with "pagehide"
// https://developer.chrome.com/articles/page-lifecycle-api/#the-unload-event
window.addEventListener("pagehide", (event) => {
  if (event.persisted){
    return;
  }
  var active_url = window.location.toString();    
  chrome.runtime.sendMessage({'name':'unload', 'page':active_url}, (response) => {
    console.log("UNLOAD-EVENT -- Response received")
  })
  window.clearInterval(intervalFast);  
});

// event triggered when a tab gets in focus
window.addEventListener("focus", () => {   
  var active_url = window.location.toString();  
  chrome.runtime.sendMessage({'name':'focus', 'page':active_url}, (response) => {
    console.log("FOCUS-EVENT -- Response received")
  })  
});

// event triggered when user moves tab or leave the browser 
window.addEventListener("blur", () => { 
  var active_url = window.location.toString();  
    chrome.runtime.sendMessage({'name':'blur', 'page':active_url}, (response) => {
    console.log("BLUR-EVENT -- Response received")
  })          
});


/*  <button aria-label="Show Your Location" aria-pressed="false" id="sVuEFc" jstcache="721" jsaction="mylocation.onButtonClick;ptrdown:ripple.play;mousedown:ripple.play;keydown:ripple.play" class="Tc0rEd Zf54rc L6Bbsd" jsan="7.Tc0rEd,7.Zf54rc,7.L6Bbsd,0.aria-label,0.aria-pressed,0.id,22.jsaction"> <div jstcache="722" class="mNcDk bpLs1b" jsan="7.mNcDk,7.bpLs1b"> </div> </button> */
function check_location(){
  var button = document.getElementById('sVuEFc');
  if(button !== null){
    console.log("Found my location button")
    button.click()
  } else {
    console.log("Button not found")
  }
}

// ask background.js to take a screenshot (not used anymore - might be useful though now) TOCHECK
let get_screenshot = function(){
  chrome.runtime.sendMessage({name:'screenshot'}, (response) => {
    console.log("Response received")
    if (response['shouldStop']){
      window.clearInterval(intervalScreenshot);  
    }
  })
}

  function triggerMouseEvent (node, eventType) {
    var clickEvent = document.createEvent ('MouseEvents');
    clickEvent.initEvent (eventType, true, true);
    node.dispatchEvent (clickEvent);
}

// collect stats for nerds 
function monitorStatsNerds() {  
    console.log("[monitorStatsNerds] started"); 
    var timePassed = Date.now() - launchTime;
    var movie_player = document.getElementById("movie_player");
    var yt_stats = {}
    if (movie_player){
      yt_stats["nerd_stats"]   = movie_player.getStatsForNerds();
      yt_stats["debug_text"]   = movie_player.getDebugText();
      yt_stats["current_time"] = movie_player.getCurrentTime();
      yt_stats["video_stat"]   = movie_player.getVideoStats();
      yt_stats["player_state"] = movie_player.getPlayerState();    
      // console.log('=>', yt_stats['video_stat']['optimal_format'], yt_stats['nerd_stats']['bandwidth_kbps'], yt_stats['nerd_stats']['dims_and_frames'], yt_stats['nerd_stats']['resolution'], yt_stats['nerd_stats']['buffer_health_seconds'])
      youtube_data.push(yt_stats);
    } else {
      console.log("movie_player is null :("); 
    }
    if (timePassed >= MAX_YOUTUBE) {
      console.log("youtube is done. Duration:", timePassed); 
      window.postMessage({'name':'youtube_stats', 'msg':youtube_data}, "*");
    } else {
      setTimeout(monitorStatsNerds, 1000);
    }
}

// collect data from browsing; 
let startCollect = function(){    
    const timing = performance.getEntriesByType('navigation')[0].toJSON();
    //console.log(timing)
    timing.start = performance.timing.requestStart;
    delete timing.serverTiming;
    var timePassed = Date.now() - launchTime;
    //console.log("==>", timePassed)
    if (timing.duration > 0 || timePassed > BROWSING_TIMEOUT) { // testing timeout      
      // fetchStart sometimes negative in FF, make an adjustment based on fetchStart
      var adjustment = timing.fetchStart < 0 ? - timing.fetchStart : 0;
      ['domainLookupStart',
        'domainLookupEnd',
        'connectStart',
        'connectEnd',
        'requestStart',
        'responseStart',
        'responseEnd',
        'domComplete',
        'domInteractive',
        'domContentLoadedEventStart',
        'domContentLoadedEventEnd',
        'loadEventStart',
        'loadEventEnd',        //PLT
        'duration'
      ].forEach(i => {
        timing[i] +=adjustment;
      });
      console.log("Done collecting performance. Time passed:", timing.duration, "=>", timing)
      
      // we have only 4 chars in our disposal including decimal point
      var duration = timing.duration / 1000;
      var precision = (duration >= 100) ? 0 : (duration >= 10 ? 1 : 2);
      var time = duration.toFixed(precision).substring(0, 4);
      chrome.runtime.sendMessage({'name':'browser', 'msg':timing}, (response) => { })
      setTimeout(function() { alert("👍 You can now close the tab, and return to the addon 👍"); }, 1000);
    } else {
      setTimeout(startCollect, 300);
    }
  }


// dump screen info for fast.com 
let dump_screen = function(){    
  // this allows to click for more info and also get upload info -- kinda heavy
  var button = document.getElementById('show-more-details-link'); 
  if(button !== null){
    if(button.style.cssText == "display: block;" && ! alertSent){
      console.log("Found and pressed <<show-more-details-link>>"); 
      button.click()   
      pressedInfo = true; 
    }
  }  
  
  // check time passed 
  var timePassed = (Date.now() - launchTime)/1000; 
  console.log("TimePassed:", timePassed)

  // check if the measurement was completed (green cicular arrow) and we can inform the user!
  var status = 'PENDING'
  var progress_button = document.getElementById('speed-progress-indicator'); 
  if(progress_button !== null){
    var curr_class = progress_button.className;
    console.log("Found wheel class", curr_class); 
    if((pressedInfo && curr_class.includes('succeeded')) || timePassed >= MAX_SPEEDTEST_DUR){  
      console.log("Found wheel stopped spinning, or time expired")
      setTimeout(function() { alert("👍 You can now close the tab, and return to the addon 👍"); }, 2000);
      alertSent = true;       
      console.log("Alert sent. Clearing intervalFast")   
      window.clearInterval(intervalFast);     
      status = 'DONE'
    }
  } else {
    console.log("Either not ready or still measuring upload...")
  }

  // report HTML and status
  var elem = document.documentElement.innerHTML; 
  chrome.runtime.sendMessage({'name':'fast', 'msg':elem, 'status':status}, (response) => {
    // never run a speedtest for more than one minute
    if (response['shouldStop']){
      console.log("Response received. SHOULD STOP")   
      window.clearInterval(intervalFast); 
    }
  })

}

// helper to discover which app is under test
let check_app_under_test  = function(){    
  // detect which app is in use 
  var active_url = window.location.toString();  
  if(active_url.includes("zoom")){ 
    app = "zoom"
  } else if (active_url.includes("webex")){ 
    app = "webex"
  } else if (active_url.includes("meet")){ 
    app = "meet"
  } else if (active_url.includes("fast")){ 
    app = "fast"    
  } else {
    // this might only be need by webex
    chrome.runtime.sendMessage({name:'getapp'}, (response) => {
      console.log("Empty URL, probably webex. Checking with backend. ANS:", response);
      app = response['lastapp']
    })
  }
}